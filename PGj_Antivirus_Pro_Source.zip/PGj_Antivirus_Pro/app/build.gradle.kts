plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.pgj.antivirus"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.pgj.antivirus"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-test"
    }
    buildTypes { release { isMinifyEnabled = false } }
    kotlinOptions { jvmTarget = "17" }
}
