package com.pgj.antivirus

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 15, 29)
    private val panel = Color.rgb(20, 29, 47)
    private val green = Color.rgb(75, 235, 165)
    private val muted = Color.rgb(157, 173, 195)
    private val white = Color.rgb(241, 246, 255)
    private lateinit var statusText: TextView
    private lateinit var resultText: TextView
    private lateinit var scanButton: Button
    private val history = mutableListOf<String>()
    private val isEnglish: Boolean
        get() = !(resources.configuration.locales[0]?.language ?: "sq").startsWith("sq")
    private fun tr(sq: String, en: String) = if (isEnglish) en else sq
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        renderHome()
    }

    private fun txt(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(16), dp(17), dp(16))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), Color.rgb(40, 57, 78))
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(14)
        }
    }

    private fun addLine(parent: LinearLayout, text: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0) {
        val v = txt(text, size, color, bold)
        v.setPadding(0, dp(top), 0, dp(5))
        parent.addView(v)
    }

    private fun renderHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(14))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "⬡"
            textSize = 38f
            gravity = Gravity.CENTER
            setTextColor(green)
            setTypeface(typeface, Typeface.BOLD)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(20, 52, 55)); cornerRadius = dp(17).toFloat(); setStroke(dp(1), green)
            }
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brand.addView(txt("PGj Antivirus", 21f, white, true))
        brand.addView(txt("PRO  •  ${tr("SIGURI PËR ANDROID", "ANDROID SECURITY")}", 10f, green, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val menu = Button(this).apply {
            text = "⋮"; textSize = 24f; setTextColor(white)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(14).toFloat() }
            setOnClickListener { showMenu() }
        }
        header.addView(menu, LinearLayout.LayoutParams(dp(48), dp(48)))
        content.addView(header)
        addLine(content, tr("Qetësi dixhitale, çdo ditë.", "Digital peace of mind, every day."), 14f, muted, top = 17)

        val security = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        addLine(security, tr("PANELI I SIGURISË", "SECURITY OVERVIEW"), 11f, muted, true)
        val shield = TextView(this).apply {
            text = "✓"; textSize = 44f; gravity = Gravity.CENTER; setTextColor(green)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(19, 54, 52)); setStroke(dp(2), green)
            }
        }
        security.addView(shield, LinearLayout.LayoutParams(dp(100), dp(100)).apply { gravity = Gravity.CENTER; topMargin = dp(8); bottomMargin = dp(8) })
        statusText = txt(tr("Gati për skanim", "Ready to scan"), 22f, white, true)
        security.addView(statusText)
        addLine(security, tr("Nis skanimin për të kontrolluar aplikacionet e dukshme.", "Start a scan to check visible apps."), 12f, muted, top = 5)
        scanButton = Button(this).apply {
            text = tr("⟲   SKANO TELEFONIN", "⟲   SCAN DEVICE")
            textSize = 15f; setTextColor(Color.rgb(5, 25, 24)); setTypeface(typeface, Typeface.BOLD)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(green); cornerRadius = dp(15).toFloat() }
            setOnClickListener { scanApps() }
        }
        security.addView(scanButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(15) })
        content.addView(security)

        val results = card()
        addLine(results, tr("REZULTATI I FUNDIT", "LATEST RESULTS"), 11f, muted, true)
        resultText = txt(tr("Ende nuk është kryer asnjë skanim.", "No scan has been run yet."), 14f, white)
        results.addView(resultText)
        content.addView(results)

        val tools = card()
        addLine(tools, tr("MJETET E SIGURISË", "SECURITY TOOLS"), 11f, muted, true)
        addTool(tools, "▦", tr("Kontrollo skedar", "Check a file"), tr("Zgjidh një skedar për kontroll bazë.", "Choose a file for a basic check.")) { pickFile() }
        addTool(tools, "◷", tr("Historiku", "Scan history"), tr("Shiko rezultatet e skanimeve.", "View scan results.")) { showHistory() }
        addTool(tools, "⚙", tr("Rreth aplikacionit", "About this app"), tr("Privatësia dhe kufizimet.", "Privacy and limitations.")) { showAbout() }
        content.addView(tools)
        addLine(content, tr("Kontrolle lokale • Privatësi në radhë të parë", "Local checks • Privacy first"), 11f, muted)
        setContentView(root)
    }

    private fun addTool(parent: LinearLayout, icon: String, title: String, subtitle: String, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { action() }
        }
        row.addView(txt(icon, 24f, green, true), LinearLayout.LayoutParams(dp(42), -2))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(txt(title, 15f, white, true))
        texts.addView(txt(subtitle, 11f, muted))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(txt("›", 25f, muted))
        parent.addView(row)
        parent.addView(View(this).apply { setBackgroundColor(Color.rgb(39, 51, 70)) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun showMenu() {
        val options = arrayOf(tr("Paneli kryesor", "Dashboard"), tr("Skanimi i aplikacioneve", "App scan"),
            tr("Kontrollo skedar", "Check a file"), tr("Historiku", "History"), tr("Privatësia dhe kufizimet", "Privacy & limitations"))
        AlertDialog.Builder(this).setTitle("PGj Antivirus Pro").setItems(options) { _, which ->
            when (which) { 0 -> renderHome(); 1 -> scanApps(); 2 -> pickFile(); 3 -> showHistory(); 4 -> showAbout() }
        }.show()
    }

    private fun scanApps() {
        scanButton.isEnabled = false
        statusText.text = tr("Duke kontrolluar…", "Scanning…")
        resultText.text = tr("Po analizohet lista e aplikacioneve të dukshme.", "Checking visible apps…")
        Thread {
            val findings = mutableListOf<String>()
            var checked = 0
            try {
                val launcherIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
                val packages = packageManager.queryIntentActivities(launcherIntent, 0).map { it.activityInfo.packageName }.distinct()
                for (pkg in packages) {
                    checked++
                    try {
                        val info = packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                        val permissions = info.requestedPermissions ?: emptyArray()
                        val sensitive = permissions.filter { it in setOf(
                            "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS",
                            "android.permission.RECORD_AUDIO", "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG",
                            "android.permission.CAMERA", "android.permission.ACCESS_FINE_LOCATION"
                        ) }
                        if (sensitive.size >= 4) {
                            findings.add("${packageManager.getApplicationLabel(info.applicationInfo)} ($pkg): ${sensitive.size} sensitive permissions")
                        }
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
            val summary = if (findings.isEmpty())
                tr("U kontrolluan $checked aplikacione të dukshme. Nuk u gjetën modele me shumë leje të ndjeshme.",
                   "$checked visible apps checked. No apps matched the sensitive-permission heuristic.")
            else tr("U kontrolluan $checked aplikacione. ${findings.size} duhen shqyrtuar për leje të ndjeshme.",
                    "$checked apps checked. ${findings.size} should be reviewed for sensitive permissions.")
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            runOnUiThread {
                statusText.text = tr("Skanimi përfundoi", "Scan complete")
                resultText.text = summary + if (findings.isNotEmpty()) "\n\n" + findings.take(8).joinToString("\n") else ""
                history.add(0, "$stamp\n$summary")
                scanButton.isEnabled = true
                AlertDialog.Builder(this).setTitle(tr("Skanimi përfundoi", "Scan complete"))
                    .setMessage(summary + "\n\n" + tr("Ky kontroll është heuristik dhe nuk provon se një aplikacion është virus.",
                        "This is a heuristic check and does not prove an app is malware."))
                    .setPositiveButton(tr("Në rregull", "OK"), null).show()
            }
        }.start()
    }

    private val pickerRequest = 4721
    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(intent, pickerRequest)
    }

    @Deprecated("Compatibility with standard Android file picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickerRequest && resultCode == RESULT_OK) data?.data?.let { inspectFile(it) }
    }

    private fun inspectFile(uri: Uri) {
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0 || total >= 100L * 1024 * 1024) break
                    digest.update(buffer, 0, n); total += n
                }
            } ?: throw IllegalStateException()
            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val name = uri.lastPathSegment ?: "selected file"
            val msg = tr(
                "Skedari: $name\nBytes të lexuara: $total\nSHA-256: $hash\n\nKy version nuk krahason hash-in me një bazë malware, ndaj nuk mund të konfirmojë infeksionin.",
                "File: $name\nBytes read: $total\nSHA-256: $hash\n\nThis version does not compare the hash against a malware database, so it cannot confirm infection.")
            AlertDialog.Builder(this).setTitle(tr("Kontroll bazë i skedarit", "Basic file check"))
                .setMessage(msg).setPositiveButton("OK", null).show()
        } catch (_: Exception) {
            AlertDialog.Builder(this).setTitle(tr("Skedari nuk u lexua", "Could not read file"))
                .setMessage(tr("Android nuk lejoi leximin e skedarit.", "Android did not allow reading this file."))
                .setPositiveButton("OK", null).show()
        }
    }

    private fun showHistory() {
        val text = if (history.isEmpty()) tr("Nuk ka ende skanime.", "No scans yet.") else history.take(10).joinToString("\n\n")
        AlertDialog.Builder(this).setTitle(tr("Historiku i skanimeve", "Scan history")).setMessage(text)
            .setPositiveButton("OK", null).show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this).setTitle(tr("Privatësia dhe kufizimet", "Privacy & limitations"))
            .setMessage(tr(
                "Ky version është prototip. Kryen kontrolle heuristike dhe llogarit SHA-256 për skedarë të zgjedhur, por nuk ka ende bazë nënshkrimesh malware, mbrojtje në kohë reale, karantinë apo shërbim për përditësime. Lejet e ndjeshme nuk provojnë se aplikacioni është malware. Për publikim në Google Play duhen testim, politikë privatësie dhe plotësimi i politikave.",
                "This is a prototype. It uses heuristics and calculates SHA-256 for selected files, but does not yet have malware signatures, real-time protection, quarantine, or an update service. Sensitive permissions do not prove an app is malware. Google Play release requires testing, a privacy policy, and policy compliance.")
            ).setPositiveButton("OK", null).show()
    }
}
